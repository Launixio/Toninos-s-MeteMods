@echo off
setlocal

color 0F
title Instalador de Mods y Resourcepacks

set "MC_DIR=%APPDATA%\.minecraft"

cls
echo ==========================================
echo   INSTALADOR DE MODS Y RESOURCEPACKS
echo ==========================================
echo.

:: Verificar .minecraft
if not exist "%MC_DIR%" (
    echo [ERROR] No se encontro .minecraft
    pause
    exit /b
)

:: Crear carpetas si faltan
if not exist "%MC_DIR%\mods" mkdir "%MC_DIR%\mods"
if not exist "%MC_DIR%\resourcepacks" mkdir "%MC_DIR%\resourcepacks"

:: ==========================
:: LIMPIAR MODS
:: ==========================
echo [LIMPIANDO] mods...
del /Q "%MC_DIR%\mods\*" >nul 2>&1
for /D %%x in ("%MC_DIR%\mods\*") do rd /S /Q "%%x" >nul 2>&1
echo [OK] mods limpio
echo.

:: ==========================
:: LIMPIAR RESOURCEPACKS
:: ==========================
echo [LIMPIANDO] resourcepacks...
del /Q "%MC_DIR%\resourcepacks\*" >nul 2>&1
for /D %%x in ("%MC_DIR%\resourcepacks\*") do rd /S /Q "%%x" >nul 2>&1
echo [OK] resourcepacks limpio
echo.

:: ==========================
:: COPIAR MODS
:: ==========================
echo ==========================================
echo           COPIANDO MODS
echo ==========================================
echo.

for %%f in ("%~dp0mods\*") do (
    echo [+] %%~nxf
    copy "%%f" "%MC_DIR%\mods\" >nul
)

echo.

:: ==========================
:: COPIAR RESOURCEPACKS
:: ==========================
echo ==========================================
echo      COPIANDO RESOURCEPACKS
echo ==========================================
echo.

for %%f in ("%~dp0resourcepacks\*") do (
    echo [+] %%~nxf
    copy "%%f" "%MC_DIR%\resourcepacks\" >nul
)

echo.
echo ==========================================
echo        INSTALACION COMPLETA
echo ==========================================
echo.

pause